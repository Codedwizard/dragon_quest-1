﻿Version: 2.1
name: nitroglycerine
By: AiTechEye

powerful explosion / nitrogen api

======freese object======
nitroglycerine.freese(object)

======all alternatives have standard values, so nothing hav to be set======
nitroglycerine.explotion(pos,{
	radius=5,
	set="node",
	place={nodes},
	place_chance=5,
	user_name="name",
	drops=1
	velocity=1
	hurt=1
	})