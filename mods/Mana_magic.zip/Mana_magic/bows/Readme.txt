License: CC0
Name: bows
Created by: AiTechEye
Version: 2

A very easy bow api mod with arrows

Load a bow:
place a arrow left of the bow + use it

Bows / levels:
Wooded
Stone
Steel
Bronze
Osidian
Mese
Diamond
Rainbow
Admin: bows:bow_admin (unlimited + very high level)

Arrows / level:
Wooded
Steel
Gold
Diamond
Dig: digs the block it hits.
Fire: spawning fire on the block or object it hits
Build: placing a block from the right stack of the bow.
Toxic: keep hurting after it hits.
Tetanus: makes you cant move (will not work with other arrows)
TNT: explosion
Admin: bows:arrow_admin (always kill when hits)
Nitrogen: freeze
Nitrogen: TNT: freeze explosion
Radioactive, keep hurting everything around the hit, makes them radioactive too in a unlimited range as long there are something more to affect.
Nuke: massive explosion


The target gives a mesecon signal when an arrow hits it.